import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import { JournalEntry } from '../types';

interface MoodChartProps {
  entries: JournalEntry[];
  isDarkMode?: boolean;
}

const MoodChart: React.FC<MoodChartProps> = ({ entries, isDarkMode = false }) => {
  // Sort entries by timestamp to ensure chronological order
  const sortedEntries = [...entries].sort((a, b) => a.timestamp - b.timestamp);

  // Format data for the chart
  const data = sortedEntries.map(entry => ({
    date: new Date(entry.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
    mood: entry.mood,
    fullDate: new Date(entry.timestamp).toLocaleDateString()
  }));

  if (entries.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-400 dark:text-slate-500 transition-colors">
        No mood data available yet. Start journaling!
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 transition-colors duration-300">
      <h3 className="text-lg font-semibold text-slate-800 dark:text-white mb-4">Mood History</h3>
      <div className="h-[300px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            data={data}
            margin={{
              top: 5,
              right: 30,
              left: 0,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? '#334155' : '#f1f5f9'} />
            <XAxis 
              dataKey="date" 
              stroke="#94a3b8" 
              fontSize={12} 
              tickLine={false}
            />
            <YAxis 
              domain={[1, 5]} 
              stroke="#94a3b8" 
              fontSize={12} 
              ticks={[1, 2, 3, 4, 5]} 
              tickLine={false}
            />
            <Tooltip 
              contentStyle={{ 
                borderRadius: '8px', 
                border: isDarkMode ? '1px solid #334155' : 'none', 
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                backgroundColor: isDarkMode ? '#1e293b' : '#fff',
                color: isDarkMode ? '#fff' : '#0f172a'
              }}
            />
            <ReferenceLine y={3} stroke={isDarkMode ? '#475569' : '#e2e8f0'} strokeDasharray="3 3" />
            <Line
              type="monotone"
              dataKey="mood"
              stroke="#0ea5e9"
              strokeWidth={3}
              activeDot={{ r: 6, fill: '#0284c7' }}
              dot={{ r: 4, fill: '#0ea5e9', strokeWidth: 0 }}
              animationDuration={1500}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default MoodChart;