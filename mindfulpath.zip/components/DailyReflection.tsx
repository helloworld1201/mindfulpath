import React, { useState, useRef } from 'react';
import { JournalEntry } from '../types';
import { generateReflectiveInsight, transcribeAudio } from '../services/geminiService';
import { Save, Sparkles, Loader2, Mic, Square } from 'lucide-react';

interface DailyReflectionProps {
  onSave: (entry: JournalEntry) => void;
}

const DailyReflection: React.FC<DailyReflectionProps> = ({ onSave }) => {
  const [mood, setMood] = useState<number>(3);
  const [q1, setQ1] = useState('');
  const [q2, setQ2] = useState('');
  const [q3, setQ3] = useState('');
  const [q4, setQ4] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Recording states
  const [recordingField, setRecordingField] = useState<string | null>(null);
  const [isTranscribing, setIsTranscribing] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const handleStartRecording = async (fieldId: string) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/webm' });
        // Stop all tracks to release mic
        stream.getTracks().forEach(track => track.stop());
        
        // Transcribe
        try {
          setIsTranscribing(fieldId);
          const base64 = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
              const result = reader.result as string;
              const b64 = result.split(',')[1];
              resolve(b64);
            };
            reader.onerror = reject;
            reader.readAsDataURL(audioBlob);
          });

          const text = await transcribeAudio(base64, 'audio/webm');
          
          // Append text to the correct field
          if (text) {
            const finalText = text.trim();
            if (fieldId === 'q1') setQ1(prev => prev + (prev ? ' ' : '') + finalText);
            if (fieldId === 'q2') setQ2(prev => prev + (prev ? ' ' : '') + finalText);
            if (fieldId === 'q3') setQ3(prev => prev + (prev ? ' ' : '') + finalText);
            if (fieldId === 'q4') setQ4(prev => prev + (prev ? ' ' : '') + finalText);
          }
        } catch (err) {
          console.error(err);
          alert("Failed to transcribe audio. Please try again.");
        } finally {
          setIsTranscribing(null);
        }
      };

      mediaRecorder.start();
      setRecordingField(fieldId);
    } catch (err) {
      console.error("Error accessing microphone:", err);
      alert("Could not access microphone. Please ensure permissions are granted.");
    }
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
      setRecordingField(null);
    }
  };

  const toggleRecording = (fieldId: string) => {
    if (recordingField === fieldId) {
      handleStopRecording();
    } else if (recordingField) {
      // Stop other recording first (simplified logic, could be improved)
      alert("Please stop the current recording first.");
    } else {
      handleStartRecording(fieldId);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!q1 || !q2 || !q3 || !q4) {
      alert("Please answer all reflection questions.");
      return;
    }

    setIsAnalyzing(true);
    let analysis = "";

    try {
      // Optional: Get AI insight immediately upon saving
      analysis = await generateReflectiveInsight(q1, q2, q3, q4, mood);
    } catch (error) {
      console.error("Failed to generate AI insight, saving without it.", error);
    } finally {
      setIsAnalyzing(false);
    }

    const newEntry: JournalEntry = {
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      timestamp: Date.now(),
      mood,
      q1,
      q2,
      q3,
      q4,
      aiAnalysis: analysis
    };

    onSave(newEntry);
    
    // Reset form
    setMood(3);
    setQ1('');
    setQ2('');
    setQ3('');
    setQ4('');
  };

  const moodEmoji = (score: number) => {
    switch(score) {
      case 1: return "😢";
      case 2: return "😕";
      case 3: return "😐";
      case 4: return "🙂";
      case 5: return "😁";
      default: return "😐";
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white dark:bg-slate-800 p-8 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 transition-colors duration-300">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Daily Reflection</h2>
        <div className="flex items-center text-sm text-brand-600 dark:text-brand-400 bg-brand-50 dark:bg-brand-900/30 px-3 py-1 rounded-full">
          <Sparkles className="w-4 h-4 mr-2" />
          <span>AI Insights Enabled</span>
        </div>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Mood Selector */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">How are you feeling today? (1-5)</label>
          <div className="flex justify-between items-center bg-slate-50 dark:bg-slate-700/50 p-4 rounded-xl">
            {[1, 2, 3, 4, 5].map((score) => (
              <button
                key={score}
                type="button"
                onClick={() => setMood(score)}
                className={`flex flex-col items-center justify-center w-12 h-12 rounded-full transition-all duration-200 ${
                  mood === score 
                    ? 'bg-brand-500 text-white scale-110 shadow-md' 
                    : 'bg-white dark:bg-slate-600 text-slate-400 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-500'
                }`}
              >
                <span className="text-xl">{moodEmoji(score)}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Questions */}
        <div className="space-y-4">
          {[
            { id: 'q1', label: 'What went well today?', value: q1, setter: setQ1 },
            { id: 'q2', label: 'What could be better?', value: q2, setter: setQ2 },
            { id: 'q3', label: 'What did I learn?', value: q3, setter: setQ3 },
            { id: 'q4', label: 'What will I do tomorrow?', value: q4, setter: setQ4 },
          ].map((field) => (
            <div key={field.id} className="relative group">
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{field.label}</label>
              <div className="relative">
                <textarea
                  value={field.value}
                  onChange={(e) => field.setter(e.target.value)}
                  className="w-full p-3 border border-slate-200 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-brand-400 focus:border-transparent outline-none transition-all text-slate-700 dark:text-white bg-white dark:bg-slate-900 placeholder:text-slate-300 dark:placeholder:text-slate-600 pr-12"
                  rows={2}
                  placeholder="Reflect on this... (Type or speak)"
                  required
                  disabled={recordingField !== null && recordingField !== field.id}
                />
                
                <button
                  type="button"
                  onClick={() => toggleRecording(field.id)}
                  disabled={isTranscribing !== null || (recordingField !== null && recordingField !== field.id)}
                  className={`absolute bottom-2 right-2 p-2 rounded-full transition-all ${
                    recordingField === field.id 
                      ? 'bg-red-100 text-red-600 animate-pulse' 
                      : 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-600'
                  } disabled:opacity-50 disabled:cursor-not-allowed`}
                  title={recordingField === field.id ? "Stop recording" : "Start voice input"}
                >
                  {isTranscribing === field.id ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : recordingField === field.id ? (
                    <Square className="w-4 h-4 fill-current" />
                  ) : (
                    <Mic className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>

        <button
          type="submit"
          disabled={isAnalyzing || recordingField !== null || isTranscribing !== null}
          className="w-full bg-brand-600 hover:bg-brand-700 text-white font-medium py-3 px-4 rounded-xl transition-all shadow-sm hover:shadow-md flex items-center justify-center disabled:opacity-70 disabled:cursor-not-allowed"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Analyzing & Saving...
            </>
          ) : (
            <>
              <Save className="w-5 h-5 mr-2" />
              Save Entry
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default DailyReflection;