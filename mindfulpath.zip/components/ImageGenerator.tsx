import React, { useState } from 'react';
import { generateTherapeuticImage } from '../services/geminiService';
import { AspectRatio, GeneratedImage } from '../types';
import { Image as ImageIcon, Sparkles, Loader2, Download } from 'lucide-react';

interface ImageGeneratorProps {
  savedImages: GeneratedImage[];
  onImageSave: (img: GeneratedImage) => void;
}

const ImageGenerator: React.FC<ImageGeneratorProps> = ({ savedImages, onImageSave }) => {
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentImage, setCurrentImage] = useState<string | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setIsGenerating(true);
    setCurrentImage(null);

    try {
      const imageUrl = await generateTherapeuticImage(prompt, aspectRatio);
      setCurrentImage(imageUrl);
      
      const newImage: GeneratedImage = {
        id: crypto.randomUUID(),
        url: imageUrl,
        prompt,
        aspectRatio,
        createdAt: Date.now()
      };
      
      onImageSave(newImage);
    } catch (error) {
      console.error("Failed to generate image", error);
      alert("Failed to generate image. Please check your API key and try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* Generator Controls */}
      <div className="md:col-span-1 space-y-6">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 transition-colors duration-300">
          <div className="flex items-center mb-4">
            <ImageIcon className="w-5 h-5 text-brand-600 dark:text-brand-400 mr-2" />
            <h2 className="text-lg font-bold text-slate-800 dark:text-white">Creative Therapy</h2>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
            Visualize your feelings or create a calming scene using AI.
          </p>
          
          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase text-slate-400 dark:text-slate-500 mb-1 tracking-wider">Prompt</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="A peaceful garden with a flowing stream..."
                className="w-full p-3 border border-slate-200 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-brand-400 focus:border-transparent outline-none text-sm min-h-[100px] bg-white dark:bg-slate-900 text-slate-800 dark:text-white placeholder:text-slate-300 dark:placeholder:text-slate-600 transition-colors"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-400 dark:text-slate-500 mb-1 tracking-wider">Aspect Ratio</label>
              <div className="grid grid-cols-3 gap-2">
                {(['1:1', '3:4', '4:3', '9:16', '16:9'] as AspectRatio[]).map((ratio) => (
                  <button
                    key={ratio}
                    type="button"
                    onClick={() => setAspectRatio(ratio)}
                    className={`px-2 py-2 text-xs rounded-md border transition-colors ${
                      aspectRatio === ratio
                        ? 'bg-brand-50 dark:bg-brand-900/30 border-brand-500 dark:border-brand-500 text-brand-700 dark:text-brand-300 font-medium'
                        : 'border-slate-200 dark:border-slate-600 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                    }`}
                  >
                    {ratio}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={isGenerating}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 px-4 rounded-lg transition-all flex items-center justify-center disabled:opacity-70"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Art
                </>
              )}
            </button>
          </form>
        </div>
      </div>

      {/* Display Area */}
      <div className="md:col-span-2">
        {currentImage ? (
          <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col items-center animate-fade-in transition-colors duration-300">
            <h3 className="text-lg font-semibold text-slate-800 dark:text-white mb-4 self-start">Your Creation</h3>
            <div className="relative group">
                <img 
                  src={currentImage} 
                  alt="Generated therapeutic art" 
                  className="rounded-lg shadow-md max-h-[500px] object-contain"
                />
                <a 
                  href={currentImage} 
                  download={`mindful-art-${Date.now()}.jpg`}
                  className="absolute bottom-4 right-4 bg-white/90 dark:bg-slate-800/90 p-2 rounded-full text-slate-700 dark:text-slate-300 shadow-lg hover:bg-white dark:hover:bg-slate-700 hover:text-brand-600 dark:hover:text-brand-400 transition-all opacity-0 group-hover:opacity-100"
                >
                  <Download className="w-5 h-5" />
                </a>
            </div>
            <p className="mt-4 text-slate-600 dark:text-slate-300 italic">"{prompt}"</p>
          </div>
        ) : (
          <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 h-full min-h-[400px] flex flex-col items-center justify-center text-slate-400 dark:text-slate-500 transition-colors duration-300">
            {savedImages.length > 0 ? (
               <div className="grid grid-cols-2 md:grid-cols-3 gap-4 w-full overflow-y-auto max-h-[500px]">
                  {savedImages.map((img) => (
                    <div key={img.id} className="relative aspect-square rounded-lg overflow-hidden group cursor-pointer" onClick={() => {
                        setCurrentImage(img.url);
                        setPrompt(img.prompt);
                    }}>
                       <img src={img.url} alt={img.prompt} className="w-full h-full object-cover" />
                       <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  ))}
               </div>
            ) : (
                <>
                    <Sparkles className="w-12 h-12 mb-4 text-slate-300 dark:text-slate-600" />
                    <p>Your creative visualization will appear here.</p>
                </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ImageGenerator;