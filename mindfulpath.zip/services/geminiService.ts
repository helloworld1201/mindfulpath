import { GoogleGenAI, Type } from "@google/genai";
import { AspectRatio, DailyKnowledge } from "../types";

const getAiClient = () => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY is missing");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

// Excerpts from "Lucky by Design" by Judd Kessler
const LUCKY_BY_DESIGN_CONTENT = [
  "Economists—myself included—think of the world as a set of markets in which individuals try to get the best outcomes they can. But the field of market design had a keen interest in different kinds of markets—markets that allocate valuable, scarce resources without relying on prices. Without prices, these markets need some other criteria to determine who gets what, and because the criteria are not always obvious or visible the way that prices are, I call them hidden markets.",
  "For an allocation mechanism to be equitable, it must treat people fairly. Instead of awarding benefits only to those who can afford it, an equitable mechanism spreads benefits as evenly as possible. In a world where everyone had the same access to resources... using prices to allocate things would be exceedingly fair. But that is not the world we live in.",
  "For an allocation mechanism to be efficient, it should make the best possible use of the resources available. This includes not squandering any of the scarce resources available as well as allocating scarce resources to the people who value them most.",
  "For an allocation mechanism to be easy, it must not put too much of a burden on the market participants trying to use it to get what they want. If the allocation mechanism is easy, participants should be able to be honest about what they want without fear that communicating their true preferences will be held against them.",
  "No market rules can guarantee an allocation that is at once efficient, equitable, and easy. When indivisible objects need to be distributed without the use of money or other currency, we must accept that we cannot simultaneously achieve all three Es. Some rules generate more efficient outcomes at the expense of ease or equity, some sacrifice efficiency in the name of equity, and so on.",
  "The key insight from Spence’s model is that when taking an action is easier for one type of person (one who has a desirable trait) than another type of person (one who lacks that trait), taking the action can allow you to signal to others that you are in the first group. Once you understand Spence-style signaling, you start to see it everywhere.",
  "This is the beauty of the advice 'Be yourself.' Your goal, whether on the dating scene or in the job market, should not be merely to end up with the match that seems most desirable in the moment. For the match to be truly successful, you want to be sure that whomever you end up with likes you for you.",
  "You are the market designer when it comes to allocating the scarce resources that only you control: your time and attention. You decide which colleagues or clients to meet with and which organizations, if any, will get your volunteering hours. You decide which friends will get to enjoy your company... When you are in the role of market designer... you will want to keep the three-E framework in mind to make sure your allocations are equitable, efficient, and easy.",
  "Prioritizing taking care of yourself is, almost by definition, elevating to you as the market designer. But it is also efficient and equitable for other market participants. By prioritizing self-care, you can bring a better mood and attitude to your other interactions, ensuring you can give quality time and attention to those who request it from you.",
  "Even if you know nothing specific about the people you are racing against, it’s safe to assume that there are going to be more people in the race for a 7:30 p.m. reservation on Saturday than for a 4:00 p.m. reservation the following Tuesday. One strategy, what I call the go-for-gold strategy, is to make a beeline for your first choice. This high-risk, high-reward strategy is the only way to go if you will be happy with nothing short of a dinner reservation on a weekend night at a desirable time.",
  "In many markets, what one person wants can shift depending on what another person gets. This phenomenon arises in the market for residency programs... Housing lotteries are another market where we see these kinds of interconnected preferences. If you want to live near your friends, it may be helpful to see where other rooming groups end up so you can adjust your preferences after they select their rooms.",
  "To improve the efficiency of my correspondence, I have stopped tackling emails based on how fast I can deal with them. Instead, I triage them based on level of importance... This system—what economists call last in, first out—isn’t the most equitable... But it is more efficient, because many of the emails I get are from people working with me on joint projects in real time."
];

export const generateReflectiveInsight = async (
  q1: string,
  q2: string,
  q3: string,
  q4: string,
  mood: number
): Promise<string> => {
  try {
    const ai = getAiClient();
    const prompt = `
      You are a compassionate and professional psychology assistant.
      Analyze the following daily reflection entry:
      
      Mood Rating (1-5): ${mood}
      1. What went well today? ${q1}
      2. What could be better? ${q2}
      3. What did I learn? ${q3}
      4. What will I do tomorrow? ${q4}

      Please provide a brief, supportive response (max 100 words). 
      Acknowledge their feelings, validate their reflection, and offer one small, actionable piece of positive advice for tomorrow.
      Do not be overly clinical; be warm and encouraging.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Unable to generate insight at this time.";
  } catch (error) {
    console.error("Error generating insight:", error);
    throw error;
  }
};

export const generateTherapeuticImage = async (
  prompt: string,
  aspectRatio: AspectRatio
): Promise<string> => {
  try {
    const ai = getAiClient();
    
    // Enhance prompt slightly for better quality if it's too short, 
    // but generally respect user intent for therapeutic art.
    const finalPrompt = prompt.length < 10 ? `${prompt}, high quality, artistic, soothing` : prompt;

    const response = await ai.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt: finalPrompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/jpeg',
        aspectRatio: aspectRatio,
      },
    });

    const base64Image = response.generatedImages?.[0]?.image?.imageBytes;
    if (!base64Image) {
      throw new Error("No image generated");
    }

    return `data:image/jpeg;base64,${base64Image}`;
  } catch (error) {
    console.error("Error generating image:", error);
    throw error;
  }
};

export const generateDailyKnowledge = async (): Promise<DailyKnowledge> => {
  try {
    const ai = getAiClient();
    
    // Select a random excerpt from the book
    const randomExcerpt = LUCKY_BY_DESIGN_CONTENT[Math.floor(Math.random() * LUCKY_BY_DESIGN_CONTENT.length)];

    const prompt = `
      Extract a single, inspiring, bite-sized piece of wisdom or insight from the text provided below.
      The text is from the book "Lucky by Design" by Judd Kessler.
      
      TEXT:
      "${randomExcerpt}"
      
      Your task:
      1. Summarize or extract a key lesson from this text in 1-2 sentences.
      2. Return it as a JSON object with 'content', 'author' (must be "Judd Kessler"), and 'source' (must be "Lucky by Design").
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            content: { type: Type.STRING },
            author: { type: Type.STRING },
            source: { type: Type.STRING },
          },
          required: ["content", "author", "source"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as DailyKnowledge;
  } catch (error) {
    console.error("Error generating daily knowledge:", error);
    // Fallback
    return {
      content: "You are the market designer when it comes to allocating the scarce resources that only you control: your time and attention.",
      author: "Judd Kessler",
      source: "Lucky by Design"
    };
  }
};

export const transcribeAudio = async (audioBase64: string, mimeType: string): Promise<string> => {
  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: audioBase64
            }
          },
          {
            text: "Transcribe the following audio to text. The audio might be in English or Chinese. Return only the transcription."
          }
        ]
      }
    });
    return response.text || "";
  } catch (error) {
    console.error("Error transcribing audio:", error);
    throw error;
  }
};
