
export interface JournalEntry {
  id: string;
  date: string; // ISO date string
  timestamp: number;
  mood: number; // 1-5
  q1: string; // What went well today?
  q2: string; // What could be better?
  q3: string; // What did I learn?
  q4: string; // What will I do tomorrow?
  aiAnalysis?: string;
}

export type AspectRatio = '1:1' | '3:4' | '4:3' | '9:16' | '16:9';

export interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  aspectRatio: AspectRatio;
  createdAt: number;
}

export interface DailyKnowledge {
  content: string;
  source: string;
  author: string;
}

export enum Tab {
  JOURNAL = 'JOURNAL',
  DASHBOARD = 'DASHBOARD',
  WISDOM = 'WISDOM'
}
